package ar.edu.centro8.desarrollo.proyectosb;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class BasquetControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Test
    void altaJugadoresTest() throws Exception {
        String jugadoresJson = "[" +
                "{\"id\":1,\"dni\":\"11111111\",\"nombre\":\"Pedro\",\"apellido\":\"Gomez\",\"edad\":20,\"peso\":80.5,\"estatura\":1.85}," +
                "{\"id\":2,\"dni\":\"22222222\",\"nombre\":\"Juan\",\"apellido\":\"Perez\",\"edad\":22,\"peso\":78.0,\"estatura\":1.90}," +
                "{\"id\":3,\"dni\":\"33333333\",\"nombre\":\"Lucas\",\"apellido\":\"Lopez\",\"edad\":19,\"peso\":82.3,\"estatura\":1.88}," +
                "{\"id\":4,\"dni\":\"44444444\",\"nombre\":\"Martin\",\"apellido\":\"Diaz\",\"edad\":21,\"peso\":76.2,\"estatura\":1.83}," +
                "{\"id\":5,\"dni\":\"55555555\",\"nombre\":\"Santiago\",\"apellido\":\"Fernandez\",\"edad\":23,\"peso\":79.7,\"estatura\":1.92}]";

        mockMvc.perform(post("/api/basquet/jugadores")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jugadoresJson))
                .andExpect(status().isOk())
                .andExpect(content().string("1.876"));
    }
}
