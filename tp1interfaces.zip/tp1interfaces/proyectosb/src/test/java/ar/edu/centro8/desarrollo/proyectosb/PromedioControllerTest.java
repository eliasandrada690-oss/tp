package ar.edu.centro8.desarrollo.proyectosb;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class PromedioControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Test
    void promedioTest() throws Exception {
        mockMvc.perform(get("/api/promedio")
                .param("nota1", "7")
                .param("nota2", "8")
                .param("nota3", "9"))
                .andExpect(status().isOk())
                .andExpect(content().string("8.0"));
    }
}
