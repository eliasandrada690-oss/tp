package ar.edu.centro8.desarrollo.proyectosb.controllers;

import ar.edu.centro8.desarrollo.proyectosb.entities.Paciente;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
public class OdontologoController {
    private final List<Paciente> pacientes = new ArrayList<>();

    public OdontologoController() {
        pacientes.add(new Paciente(1, "12345678", "Juan", "Pérez", LocalDate.of(2010, 5, 12)));
        pacientes.add(new Paciente(2, "23456789", "Ana", "García", LocalDate.of(2005, 8, 23)));
        pacientes.add(new Paciente(3, "34567890", "Luis", "Martínez", LocalDate.of(1998, 2, 3)));
        pacientes.add(new Paciente(4, "45678901", "Sofía", "López", LocalDate.of(2012, 11, 30)));
        pacientes.add(new Paciente(5, "56789012", "Carlos", "Gómez", LocalDate.of(2007, 7, 15)));
    }

    @GetMapping("/api/odontologo/pacientes")
    public List<Paciente> getPacientes() {
        return pacientes;
    }

    @GetMapping("/api/odontologo/pacientes-menores")
    public List<Paciente> getPacientesMenores() {
        LocalDate hoy = LocalDate.now();
        return pacientes.stream()
                .filter(p -> Period.between(p.getFechaNacimiento(), hoy).getYears() < 18)
                .collect(Collectors.toList());
    }
}
