package ar.edu.centro8.desarrollo.proyectosb.controllers;

import ar.edu.centro8.desarrollo.proyectosb.entities.Jugador;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class BasquetController {
    private final List<Jugador> jugadores = new ArrayList<>();

    @PostMapping("/api/basquet/jugadores")
    public double altaJugadores(@RequestBody List<Jugador> nuevosJugadores) {
        jugadores.addAll(nuevosJugadores);
        return jugadores.stream()
                .mapToDouble(Jugador::getEstatura)
                .average()
                .orElse(0.0);
    }
}
