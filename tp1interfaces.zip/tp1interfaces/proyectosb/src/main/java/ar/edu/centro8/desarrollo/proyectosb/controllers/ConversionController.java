package ar.edu.centro8.desarrollo.proyectosb.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ConversionController {
    @GetMapping("/api/conversion/galones-a-litros")
    public double galonesALitros(@RequestParam double galones) {
        return galones * 3.78541;
    }
}
