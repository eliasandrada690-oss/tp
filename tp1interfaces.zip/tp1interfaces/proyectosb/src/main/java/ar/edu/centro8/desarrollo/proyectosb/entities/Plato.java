package ar.edu.centro8.desarrollo.proyectosb.entities;

public class Plato {
    private int numero;
    private String nombre;
    private double precio;
    private String descripcion;

    public Plato(int numero, String nombre, double precio, String descripcion) {
        this.numero = numero;
        this.nombre = nombre;
        this.precio = precio;
        this.descripcion = descripcion;
    }

    public int getNumero() { return numero; }
    public String getNombre() { return nombre; }
    public double getPrecio() { return precio; }
    public String getDescripcion() { return descripcion; }
}
