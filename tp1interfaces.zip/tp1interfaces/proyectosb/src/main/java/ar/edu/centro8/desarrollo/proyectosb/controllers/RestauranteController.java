package ar.edu.centro8.desarrollo.proyectosb.controllers;

import ar.edu.centro8.desarrollo.proyectosb.entities.Plato;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class RestauranteController {
    private final List<Plato> platos = new ArrayList<>();

    public RestauranteController() {
        platos.add(new Plato(1, "Milanesa con papas", 2500, "Carne empanada con papas fritas"));
        platos.add(new Plato(2, "Ensalada César", 1800, "Lechuga, pollo y aderezo César"));
        platos.add(new Plato(3, "Pizza Margarita", 2200, "Pizza con tomate, mozzarella y albahaca"));
        platos.add(new Plato(4, "Sopa de verduras", 1500, "Sopa casera de verduras frescas"));
        platos.add(new Plato(5, "Hamburguesa completa", 2700, "Hamburguesa con queso, tomate y lechuga"));
    }

    @GetMapping("/api/restaurante/plato")
    public Plato getPlato(@RequestParam int numero) {
        return platos.stream()
                .filter(p -> p.getNumero() == numero)
                .findFirst()
                .orElse(null);
    }
}
